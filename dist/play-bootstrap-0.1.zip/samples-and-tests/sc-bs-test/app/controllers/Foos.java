package controllers;

import java.util.List;
import models.Foo;
import play.mvc.Controller;
import play.i18n.Messages;
import play.data.validation.Validation;
import play.data.validation.Valid;
public class Foos extends Controller {
    public static void index() {
        List<Foo> entities = models.Foo.all().fetch();
        render(entities);
    }

    public static void create(Foo foo) {
        render(foo);
    }

    public static void show(java.lang.Long id) {
        Foo foo = Foo.findById(id);
        render(foo);
    }

    public static void edit(java.lang.Long id) {
        Foo foo = Foo.findById(id);
        render(foo);
    }

    public static void delete(java.lang.Long id) {
        Foo foo = Foo.findById(id);
        foo.delete();
        index();
    }
    
    public static void save(@Valid Foo foo) {
        if (validation.hasErrors()) {
            flash.error(Messages.get("scaffold.validation"));
            render("@create", foo);
        }
        foo.save();
        flash.success(Messages.get("scaffold.created", "Foo"));
        index();
    }

    public static void update(@Valid Foo foo) {
        if (validation.hasErrors()) {
            flash.error(Messages.get("scaffold.validation"));
            render("@edit", foo);
        }
                      foo = foo.merge();
                foo.save();
        flash.success(Messages.get("scaffold.updated", "Foo"));
        index();
    }
}
