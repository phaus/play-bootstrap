package controllers;

import java.util.List;
import models.Bar;
import play.mvc.Controller;
import play.i18n.Messages;
import play.data.validation.Validation;
import play.data.validation.Valid;
public class Bars extends Controller {
    public static void index() {
        List<Bar> entities = models.Bar.all().fetch();
        render(entities);
    }

    public static void create(Bar bar) {
        render(bar);
    }

    public static void show(java.lang.Long id) {
        Bar bar = Bar.findById(id);
        render(bar);
    }

    public static void edit(java.lang.Long id) {
        Bar bar = Bar.findById(id);
        render(bar);
    }

    public static void delete(java.lang.Long id) {
        Bar bar = Bar.findById(id);
        bar.delete();
        index();
    }
    
    public static void save(@Valid Bar bar) {
        if (validation.hasErrors()) {
            flash.error(Messages.get("scaffold.validation"));
            render("@create", bar);
        }
        bar.save();
        flash.success(Messages.get("scaffold.created", "Bar"));
        index();
    }

    public static void update(@Valid Bar bar) {
        if (validation.hasErrors()) {
            flash.error(Messages.get("scaffold.validation"));
            render("@edit", bar);
        }
                      bar = bar.merge();
                bar.save();
        flash.success(Messages.get("scaffold.updated", "Bar"));
        index();
    }
}
