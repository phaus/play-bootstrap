#!/bin/bash
play deps --sync
play bs:gen --with-layout --overwrite
